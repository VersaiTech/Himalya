<?php 
ob_start();
header("Location:AppLogin");
?>