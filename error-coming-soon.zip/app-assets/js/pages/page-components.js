// Components Page Menu
setTimeout(() => {
    new Swiper('.hp-components-menu .swiper', {
        slidesPerView: 'auto',
        speed: 800,
    });
}, 500);