<footer class="w-100 py-18 px-16 py-sm-24 px-sm-32 hp-bg-color-black-20 hp-bg-color-dark-90">
        <div class="row">
          <div class="col-12">
            <p class="hp-badge-text fw-semibold mb-0 text-center text-sm-start hp-text-color-dark-30">COPYRIGHT ©2024 Himallya RO Services, All rights Reserved</p>
          </div>
        </div>
</footer>